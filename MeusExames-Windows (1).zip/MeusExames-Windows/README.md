# Meus Exames — Windows

Gerar o instalador (.exe):

- Opção 1 (automática): suba esta pasta para um repositório no GitHub. Na aba *Actions*, rode "Gerar EXE (Windows)" e baixe o arquivo em *Artifacts*.
- Opção 2 (no seu PC, com Node.js 20 instalado): dentro desta pasta, rode `npm install` e depois `npm run dist`. O instalador sai em `dist/`.

Para testar sem gerar o instalador: `npm start`.

Os dados ficam só no computador (localStorage/IndexedDB do aplicativo). Para mover exames para o app principal, use "Exportar exames novos (JSON)".
