// Meus Exames — casca Electron. Abre o app local (app/index.html). Nada sai do computador.
const { app, BrowserWindow, Menu, shell, session, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { fileURLToPath } = require('url');

const INDEX = path.join(__dirname, 'app', 'index.html');

function createWindow() {
  Menu.setApplicationMenu(null);
  const win = new BrowserWindow({
    width: 1360,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: 'Meus Exames',
    icon: path.join(__dirname, 'build', 'icon.ico'),
    backgroundColor: '#F8FAFC',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  win.loadFile(INDEX);

  // Laudos originais (arquivos da pasta app/exames_originais) abrem no leitor de PDF do Windows
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('file:') && url.toLowerCase().endsWith('.pdf')) {
      shell.openPath(fileURLToPath(url));
      return { action: 'deny' };
    }
    // PDFs importados (blob:) abrem em janela própria
    return { action: 'allow', overrideBrowserWindowOptions: { width: 1000, height: 1200, title: 'Laudo' } };
  });

  // Links de download (exportação JSON) pedem onde salvar
  win.webContents.on('will-download', (_e, item) => {
    const suggested = item.getFilename();
    const picked = dialog.showSaveDialogSync(win, { defaultPath: suggested });
    if (picked) item.setSavePath(picked);
    else item.cancel();
  });
}

app.whenReady().then(() => {
  // Só permite arquivos locais; nada de rede
  session.defaultSession.webRequest.onBeforeRequest((details, cb) => {
    const ok = details.url.startsWith('file:') || details.url.startsWith('blob:') || details.url.startsWith('devtools:');
    cb({ cancel: !ok });
  });
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
