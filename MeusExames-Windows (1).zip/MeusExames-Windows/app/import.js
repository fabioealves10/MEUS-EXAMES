/* Importação de novos laudos (PDF). Tudo roda no próprio aparelho: nada é enviado a servidor. */
(function () {
  const KEY = "meusExames.novos.v1";
  const DBNAME = "meusExames", STORE = "pdfs";

  /* ---------- armazenamento local ---------- */
  function loadNovos() {
    try { return JSON.parse(localStorage.getItem(KEY)) || { points: [], files: [] }; }
    catch (e) { return { points: [], files: [] }; }
  }
  function saveNovos(n) {
    try { localStorage.setItem(KEY, JSON.stringify(n)); } catch (e) { alert("Não foi possível salvar no navegador (espaço cheio ou modo privado)."); }
  }
  function idb() {
    return new Promise((ok, err) => {
      try {
        const r = indexedDB.open(DBNAME, 1);
        r.onupgradeneeded = () => r.result.createObjectStore(STORE);
        r.onsuccess = () => ok(r.result);
        r.onerror = () => err(r.error);
      } catch (e) { err(e); }
    });
  }
  async function putPdf(name, blob) {
    const db = await idb();
    return new Promise((ok, err) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(blob, name);
      tx.oncomplete = () => ok(); tx.onerror = () => err(tx.error);
    });
  }
  async function getPdf(name) {
    const db = await idb();
    return new Promise((ok, err) => {
      const rq = db.transaction(STORE).objectStore(STORE).get(name);
      rq.onsuccess = () => ok(rq.result); rq.onerror = () => err(rq.error);
    });
  }

  /* ---------- aplicar o que foi importado aos dados do app ---------- */
  function applyNovos() {
    const n = loadNovos(), EX = window.EXAMS, META = window.META;
    n.points.forEach(p => {
      const e = EX.find(x => x.name === p.name);
      if (!e) return;
      if (e.series.some(s => s.date === p.date)) return;   // já existe essa coleta
      e.series.push({ date: p.date, value: p.value, printed: p.printed, lab: p.lab });
      e.series.sort((a, b) => a.date.localeCompare(b.date));
    });
    n.files.forEach(f => {
      META.files[f.date] = META.files[f.date] || [];
      if (!META.files[f.date].includes(f.file)) META.files[f.date].push(f.file);
      if (!META.dates.includes(f.date)) META.dates.push(f.date);
    });
    META.dates.sort();
  }
  const isImported = fname => loadNovos().files.some(f => f.file === fname);

  /* ---------- leitura do PDF ---------- */
  async function extractText(file) {
    if (!window.pdfjsLib) throw new Error("Leitor de PDF não carregado (pdf.min.js).");
    window.pdfjsLib.GlobalWorkerOptions.workerSrc = "pdf.worker.min.js";
    const pdf = await window.pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise;
    let out = "";
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const tc = await page.getTextContent();
      let lastY = null;
      for (const it of tc.items) {
        if (!it.str) continue;
        const y = it.transform[5];
        if (lastY !== null && Math.abs(y - lastY) > 2) out += "\n";
        else if (out && !out.endsWith("\n")) out += " ";
        out += it.str; lastY = y;
      }
      out += "\n";
    }
    return out;
  }
  const toNum = s => {
    let t = String(s).trim();
    if (t.includes(",")) t = t.replace(/\./g, "").replace(",", ".");
    else if (/^\d{1,3}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, "");
    const v = parseFloat(t);
    return isNaN(v) ? null : v;
  };
  const esc = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  /* ---------- tela de revisão ---------- */
  function review(file, parsed) {
    return new Promise(resolve => {
      const EX = window.EXAMS;
      const labOpts = ["Pretti", "Tommasi"];
      const dateIso = parsed.date || "";
      const found = Object.fromEntries(parsed.items.map(it => [it.name, it]));
      const rows = EX.map((e, i) => {
        const it = found[e.name];
        return { i, name: e.name, unit: e.unit, printed: it ? it.printed : "", conf: it ? it.confidence : "manual", snippet: it ? it.snippet : "", on: !!it };
      }).sort((a, b) => (b.on - a.on) || (a.i - b.i));
      const ov = document.createElement("div");
      ov.className = "imp-ov";
      ov.innerHTML = `
        <div class="imp-box" role="dialog" aria-modal="true">
          <div class="imp-h"><b>Conferir importação</b><span>${esc(file.name)}</span></div>
          <div class="imp-meta">
            <label>Data da coleta <input type="date" id="impDate" value="${esc(dateIso)}"></label>
            <label>Laboratório <select id="impLab">${labOpts.map(l => `<option ${l === parsed.lab ? "selected" : ""}>${l}</option>`).join("")}</select></label>
          </div>
          <p class="imp-tip"><b>confere</b>: valor lido do laudo. <b>conferir</b>: lido, mas sem a marcação de resultado perto do nome; confira no PDF. <b>digitar</b>: não encontrado; preencha se o laudo tiver esse exame (deixe em branco para ignorar).</p>
          <div class="imp-tbl-wrap"><table class="imp-tbl">
            <thead><tr><th></th><th>Exame</th><th>Resultado</th><th>Unid.</th><th>Situação</th></tr></thead>
            <tbody>${rows.map(r => `<tr>
              <td><input type="checkbox" data-k="on" data-i="${r.i}" ${r.on ? "checked" : ""}></td>
              <td>${esc(r.name)}<div class="imp-snip">${esc(r.snippet)}</div></td>
              <td><input class="imp-val" data-k="val" data-i="${r.i}" value="${esc(r.printed)}"></td>
              <td>${esc(r.unit)}</td>
              <td>${r.conf === "alta" ? '<span class="imp-ok">confere</span>' : r.conf === "manual" ? '<span class="imp-na">digitar</span>' : '<span class="imp-warn">conferir</span>'}</td>
            </tr>`).join("")}</tbody>
          </table></div>
          <div class="imp-f">
            <button class="imp-btn ghost" id="impCancel">Cancelar</button>
            <button class="imp-btn" id="impOk">Salvar importação</button>
          </div>
        </div>`;
      document.body.appendChild(ov);
      const done = v => { ov.remove(); resolve(v); };
      ov.querySelector("#impCancel").onclick = () => done(null);
      ov.querySelector("#impOk").onclick = () => {
        const date = ov.querySelector("#impDate").value;
        const lab = ov.querySelector("#impLab").value;
        if (!date) { alert("Informe a data da coleta."); return; }
        const points = [];
        rows.forEach(r => {
          const on = ov.querySelector(`[data-k="on"][data-i="${r.i}"]`).checked;
          const printed = ov.querySelector(`[data-k="val"][data-i="${r.i}"]`).value.trim();
          const value = toNum(printed);
          if (!on || value == null) return;
          points.push({ name: r.name, date, value, printed, lab });
        });
        done({ date, lab, file: file.name, points });
      };
    });
  }

  /* ---------- fluxo: escolher arquivos → ler → conferir → salvar ---------- */
  async function importFiles(files) {
    for (const file of Array.from(files)) {
      try {
        const text = await extractText(file);
        const parsed = window.LaudoParser.parseLaudo(text);
        const res = await review(file, parsed);
        if (!res) continue;
        const n = loadNovos();
        res.points.forEach(p => { if (!n.points.some(q => q.name === p.name && q.date === p.date)) n.points.push(p); });
        if (!n.files.some(f => f.file === file.name)) n.files.push({ file: file.name, date: res.date });
        saveNovos(n);
        await putPdf(file.name, file);
        applyNovos();
        document.dispatchEvent(new CustomEvent("examesChanged"));
      } catch (err) {
        alert(`Não foi possível ler "${file.name}": ${err.message || err}`);
      }
    }
  }

  const toB64 = blob => new Promise((ok, err) => {
    const r = new FileReader();
    r.onload = () => ok(String(r.result).split(",")[1]);
    r.onerror = () => err(r.error);
    r.readAsDataURL(blob);
  });
  const strToB64 = s => btoa(unescape(encodeURIComponent(s)));
  const bridge = () => (window.AndroidBridge && typeof window.AndroidBridge.shareFile === "function") ? window.AndroidBridge : null;

  function exportNovos() {
    const data = JSON.stringify(loadNovos(), null, 2);
    if (bridge()) { bridge().shareFile("exames_novos.json", "application/json", strToB64(data)); return; }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([data], { type: "application/json" }));
    a.download = "exames_novos.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }

  /* ---------- estilo e ligações ---------- */
  const css = `
  .imp-ov{position:fixed;inset:0;background:rgba(15,23,42,.45);display:flex;align-items:center;justify-content:center;z-index:50;padding:14px;font-family:inherit}
  .imp-box{background:#fff;border-radius:16px;box-shadow:0 20px 50px rgba(0,0,0,.25);width:min(920px,100%);max-height:92vh;display:flex;flex-direction:column;overflow:hidden;color:#0F172A;font-size:14px}
  .imp-h{display:flex;justify-content:space-between;gap:12px;align-items:baseline;padding:16px 20px;border-bottom:1px solid #E2E8F0}
  .imp-h span{color:#64748B;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .imp-meta{display:flex;gap:14px;flex-wrap:wrap;padding:14px 20px 0}
  .imp-meta label{display:flex;flex-direction:column;gap:4px;font-size:12px;color:#475569;font-weight:600}
  .imp-meta input,.imp-meta select,.imp-val{border:1px solid #CBD5E1;border-radius:8px;padding:7px 9px;font:inherit;background:#fff}
  .imp-tip{margin:10px 20px 6px;color:#64748B;font-size:12.5px}
  .imp-tbl-wrap{overflow:auto;border-top:1px solid #E2E8F0;border-bottom:1px solid #E2E8F0;flex:1 1 auto;min-height:0}
  .imp-tbl{width:100%;border-collapse:collapse;font-size:13px}
  .imp-tbl th,.imp-tbl td{padding:8px 10px;border-top:1px solid #E2E8F0;text-align:left;vertical-align:top}
  .imp-tbl th{background:#F8FAFC;font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:#64748B;position:sticky;top:0}
  .imp-val{width:110px}
  .imp-snip{color:#94A3B8;font-size:11px;margin-top:2px;max-width:520px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .imp-ok,.imp-warn,.imp-na{font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px;white-space:nowrap}
  .imp-ok{background:#DCFCE7;color:#166534}.imp-warn{background:#FEF3C7;color:#92400E}.imp-na{background:#F1F5F9;color:#475569}
  .imp-f{display:flex;justify-content:flex-end;gap:10px;padding:14px 20px}
  .imp-btn{border:0;background:#4F46E5;color:#fff;border-radius:10px;padding:10px 16px;font:inherit;font-weight:600;cursor:pointer}
  .imp-btn.ghost{background:#fff;color:#334155;border:1px solid #CBD5E1}
  .imp-side{display:flex;flex-direction:column;gap:8px;margin:4px 0 14px}
  .imp-side button{border:1px solid #CBD5E1;background:#fff;border-radius:10px;padding:9px 12px;font:inherit;font-size:13px;color:#312E81;font-weight:600;cursor:pointer;text-align:left}
  .imp-side button:hover{background:#EEF2FF}
  @media (max-width:820px){.imp-tbl th:nth-child(4),.imp-tbl td:nth-child(4){display:none}}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  const input = document.createElement("input");
  input.type = "file"; input.accept = "application/pdf,.pdf"; input.multiple = true; input.hidden = true;
  document.body.appendChild(input);
  input.onchange = () => { importFiles(input.files); input.value = ""; };

  document.addEventListener("click", async ev => {
    const t = ev.target.closest("[data-idb]");
    if (t) {
      ev.preventDefault();
      try {
        const blob = await getPdf(t.dataset.idb);
        if (!blob) { alert("PDF não encontrado neste aparelho."); return; }
        if (bridge() && typeof bridge().openPdf === "function") {
          bridge().openPdf(t.dataset.idb, await toB64(blob));
          return;
        }
        const url = URL.createObjectURL(blob);
        window.open(url, "_blank");
        setTimeout(() => URL.revokeObjectURL(url), 60000);
      } catch (e) { alert("Não foi possível abrir o PDF."); }
    }
    if (ev.target.id === "btnImport") input.click();
    if (ev.target.id === "btnExport") exportNovos();
  });

  applyNovos();
  window.ImportStore = { isImported, applyNovos, importFiles };
})();
