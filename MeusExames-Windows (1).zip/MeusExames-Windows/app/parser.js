/* Leitor de laudos (texto extraído do PDF). Heurístico: sempre passa por conferência do usuário. */
(function (root) {
  const ANALYTES = [
    ["Hemoglobina", /\bHemoglobina\b(?!\s*glicada)(?!\s*\(HbA1c\))|\bHb\b\s*\(/i],
    ["Hematócrito", /Hemat[óo]crito/i],
    ["VCM (volume corpuscular médio)", /\bVCM\b|V\.C\.M/i],
    ["Leucócitos", /Leuc[óo]citos(\s*-\s*Global|\s*\(WBC\))?/i],
    ["Plaquetas", /\bPLAQUETAS?\b/i],
    ["Glicose de jejum", /GLICOSE\s+JEJUM|Glicemia\s+de\s+Jejum|Glicose\s+de\s+jejum/i],
    ["Hemoglobina glicada (HbA1c)", /HBA1C|HbA1c|Hemoglobina\s+Glicada/i],
    ["Insulina", /\bInsulina\b/i],
    ["Colesterol total", /Colesterol\s+Total|COLESTEROL\s+TOTAL/i],
    ["HDL-colesterol", /Colesterol\s*-\s*HDL|COLESTEROL\s+HDL|HDL-colesterol/i],
    ["LDL-colesterol", /Colesterol\s*-\s*LDL|COLESTEROL\s+LDL|LDL-colesterol/i],
    ["Colesterol não-HDL", /N[ãa]o-?HDL/i],
    ["Triglicérides", /Triglicer[íi]deos?|TRIGLICERIDES/i],
    ["VLDL-colesterol", /\bVLDL\b/i],
    ["Ureia", /\bUreia\b|\bUREIA\b/],
    ["Creatinina", /Creatinina|CREATININA/i],
    ["Ácido úrico", /[ÁA]cido\s+[úu]rico|ACIDO URICO/i],
    ["Sódio", /S[óo]dio|SODIO\b/i],
    ["Potássio", /Pot[áa]ssio|POTASSIO\b/i],
    ["Cálcio total", /C[áa]lcio\s+total|C[áa]lcio:/i],
    ["Magnésio", /Magn[ée]sio|MAGNESIO\b/i],
    ["Zinco", /\bZinco\b|\bZINCO\b/i],
    ["Fósforo", /F[óo]sforo/i],
    ["TGO (AST)", /\bTGO\b|Transaminase\s+Oxalac|Transaminase\s+Glut[âa]mico-Oxalacet|TRANSAMINASE\s+OXALAC/i],
    ["TGP (ALT)", /\bTGP\b|Transaminase\s+Pir[úu]vica|Transaminase\s+Glut[âa]mico-Pir/i],
    ["Gama GT (GGT)", /\bGGT\b|Gama\s*GT|GAMA\s+GT|Gama\s+Glutamil/i],
    ["Fosfatase alcalina", /Fosfatase\s+alcalina|FOSFATASE\s+ALCALINA/i],
    ["Bilirrubina total", /Bilirrubina\s+total|BILIRRUBINA\s+TOTAL/i],
    ["Bilirrubina direta", /Bilirrubina\s+direta|BILIRRUBINA\s+DIRETA|\bDIRETA\b/i],
    ["Bilirrubina indireta", /Bilirrubina\s+indireta|BILIRRUBINA\s+INDIRETA|\bINDIRETA\b/i],
    ["Amilase", /\bAmilase\b|\bAMILASE\b/i],
    ["Lipase", /\bLipase\b|\bLIPASE\b/i],
    ["Ferritina", /Ferritina/i],
    ["Ferro sérico", /Ferro\s+s[ée]rico|Dosagem\s+de\s+Ferro|FERRO\s+S[ÉE]RICO/i],
    ["Transferrina", /Transferrina/i],
    ["Vitamina D (25-OH)", /25\s*-?\s*Hidroxi|25\s*\(OH\)\s*D|25-OH|VITAMINA\s+D/i],
    ["Vitamina B12", /Vitamina\s+B12|VITAMINA\s+B12|Cobalamina/i],
    ["Proteínas totais", /PROTE[ÍI]NAS\s+TOTAIS|Prote[íi]nas\s+totais/i],
    ["TSH", /\bTSH\b/],
    ["T4 livre", /T4\s+LIVRE|T4\s+livre/i],
    ["Testosterona total", /TESTOSTERONA\s+TOTAL|Testosterona\s+Total/i],
    ["Testosterona livre calculada", /TESTOSTERONA\s+LIVRE\s+CALCULADA|Testosterona\s+livre\s+calculada/i],
    ["Testosterona livre", /Testosterona\s+Livre\s*:/i],
    ["Testosterona biodisponível", /biodispon[íi]vel/i],
    ["Índice de andrógenos livres (FAI)", /\bFAI\b/],
    ["SHBG", /\bSHBG\b/],
    ["Estradiol (E2)", /Estradiol/i],
    ["FSH", /\bFSH\b|Horm[ôo]nio\s+Fol[íi]culo\s+Estimulante/i],
    ["LH", /\bLH\b|Horm[ôo]nio\s+Luteinizante/i],
    ["Prolactina", /Prolactina/i],
    ["IGF-1 (somatomedina C)", /IGF-?1|Somatomedina/i],
    ["PSA total", /PSA\s+TOTAL|PSA\s+Total/i],
    ["PSA livre", /PSA\s+LIVRE|PSA\s+Livre/i],
  ];
  const NUM = /(?<![\w,.\/])(\d{1,3}(?:\.\d{3})+(?:,\d+)?|\d+(?:,\d+)?|\d+\.\d+)(?![\d\/])/g;
  const STOP = /\b(Material|M[ÉE]TODO|Metodo|Valores?\s+de\s+refer|Refer[êe]ncia|Anteriores|Aten[çc][ãa]o|Obs\.?|Nota|Interpreta|C[ÁA]LCULO|Data\/Hora|Coleta|Libera[çc][ãa]o)\b/i;

  function toNumber(tok) {
    let t = tok;
    if (t.includes(",")) t = t.replace(/\./g, "").replace(",", ".");
    else if (/^\d{1,3}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, "");
    return parseFloat(t);
  }

  function detectLab(text) {
    if (/pretti/i.test(text)) return "Pretti";
    if (/tommasi|bluzz/i.test(text)) return "Tommasi";
    return null;
  }

  function detectDate(text) {
    const m = text.match(/[Cc]oleta[^0-9]{0,60}(\d{2})\/(\d{2})\/(\d{4})/);
    return m ? `${m[3]}-${m[2]}-${m[1]}` : null;
  }

  // Where does the segment for this analyte end? At the next stop word or the next analyte name.
  function segmentFor(flat, from) {
    let seg = flat.slice(from, from + 260);
    const st = seg.search(STOP);
    if (st >= 0) seg = seg.slice(0, st);
    for (const [, re] of ANALYTES) {
      const g = new RegExp(re.source, re.flags.replace("g", "") + "");
      const mm = g.exec(seg);
      if (mm && mm.index > 0) seg = seg.slice(0, mm.index);
    }
    return seg;
  }

  // Pick the result: first number after "RESULTADO" if present, otherwise first plausible number.
  function pickResult(seg) {
    let body = seg;
    const r = seg.search(/RESULTADO\s*:?/i);
    const viaResultado = r >= 0;
    if (r >= 0) body = seg.slice(r).replace(/^RESULTADO\s*:?/i, "");
    for (const n of body.matchAll(new RegExp(NUM.source, "g"))) {
      const tok = n[1], i = n.index, end = i + tok.length;
      const before = body.slice(Math.max(0, i - 6), i);
      const after = body.slice(end, end + 10);
      if (/(\(|<|>|≤|≥|\/|a|A|até|-|–)\s*$/.test(before)) continue;      // ranges, "<", "(OH)", dates
      if (/^\s*(a|A|até|-|–)\s*\d/.test(after)) continue;                  // "x a y" reference ranges
      if (/^\(/.test(after) || /^\s*(BETA|h\b|min\b|ng\/mL\s*\/)/i.test(after)) continue;
      if (/^(19|20)\d{2}$/.test(tok)) continue;                            // years in citations/dates
      return { tok, viaResultado };
    }
    return null;
  }

  // For each analyte, take the first occurrence that yields a plausible result.
  function parseLaudo(text) {
    const flat = text.replace(/\r/g, "");
    const items = [];
    for (const [name, re] of ANALYTES) {
      const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
      let m, found = null;
      while ((m = g.exec(flat)) !== null) {
        const seg = segmentFor(flat, m.index + m[0].length);
        const pick = pickResult(seg);
        if (pick) {
          const tok = pick.tok;
          let v = toNumber(tok);
          if ((name === "Leucócitos" || name === "Plaquetas") && v >= 1000) v = v / 1000;
          found = { name, value: v, printed: tok, confidence: pick.viaResultado ? "alta" : "conferir", snippet: (m[0] + " … " + seg.slice(0, 60)).replace(/\s+/g, " ") };
          break;
        }
      }
      if (found) items.push(found);
    }
    return { lab: detectLab(flat), date: detectDate(flat), items };
  }

  const api = { parseLaudo, ANALYTES };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.LaudoParser = api;
})(typeof window !== "undefined" ? window : globalThis);
